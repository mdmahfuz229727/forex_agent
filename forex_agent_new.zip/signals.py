
from config import WEIGHTS, THRESHOLDS

def generate_signal(trend, momentum, volatility, condition, session, pullback, mtf):
    bull,bear = 0.0,0.0
    warns,factors_bull,factors_bear = [],[],[]
    t = trend.get("trend","")
    if "STRONG BULLISH" in t: bull+=WEIGHTS["trend_strong"]; factors_bull.append("Strong bullish trend")
    elif "BULLISH" in t: bull+=WEIGHTS["trend_weak"]; factors_bull.append("Bullish trend")
    if "STRONG BEARISH" in t: bear+=WEIGHTS["trend_strong"]; factors_bear.append("Strong bearish trend")
    elif "BEARISH" in t: bear+=WEIGHTS["trend_weak"]; factors_bear.append("Bearish trend")
    if momentum.get("macd_bull_cross"): bull+=WEIGHTS["macd"]; factors_bull.append("MACD bullish cross")
    elif momentum.get("macd_bear_cross"): bear+=WEIGHTS["macd"]; factors_bear.append("MACD bearish cross")
    elif momentum.get("macd_above_zero") and momentum.get("macd_hist_rising"): bull+=WEIGHTS["macd"]*0.5
    elif not momentum.get("macd_above_zero") and not momentum.get("macd_hist_rising"): bear+=WEIGHTS["macd"]*0.5
    rsi_val = str(momentum.get("rsi", 50))
    rsi_lbl = str(momentum.get("rsi_label", ""))
    rsi_s = momentum.get("rsi_score", 0)
    if rsi_s>0: bull+=rsi_s; factors_bull.append("RSI: " + rsi_val + " - " + rsi_lbl)
    elif rsi_s<0: bear+=abs(rsi_s); factors_bear.append("RSI: " + rsi_val + " - " + rsi_lbl)
    if momentum.get("stoch_bull_cross") and not momentum.get("stoch_ob"): bull+=WEIGHTS["stochastic"]
    elif momentum.get("stoch_bear_cross") and not momentum.get("stoch_os"): bear+=WEIGHTS["stochastic"]
    pb=pullback.get("is_pullback",False); pb_dir=pullback.get("direction",""); pb_q=pullback.get("quality","LOW")
    pb_bonus=WEIGHTS["pullback"] if pb_q=="HIGH" else WEIGHTS["pullback"]*0.5
    if pb and pb_dir=="BULLISH": bull+=pb_bonus; factors_bull.append("Pullback entry zone")
    elif pb and pb_dir=="BEARISH": bear+=pb_bonus; factors_bear.append("Pullback entry zone")
    sess_q=session.get("quality","POOR")
    if sess_q=="EXCELLENT":
        if bull>bear: bull+=WEIGHTS["session_bonus"]
        elif bear>bull: bear+=WEIGHTS["session_bonus"]
    elif sess_q=="POOR": warns.append("Low liquidity session")
    mtf_conf=mtf.get("confluence","MIXED"); aligned=mtf.get("aligned_count",0)
    if mtf_conf=="BULLISH" and aligned>=2: bull+=WEIGHTS["mtf_confluence"]; factors_bull.append("MTF confluence")
    elif mtf_conf=="BEARISH" and aligned>=2: bear+=WEIGHTS["mtf_confluence"]; factors_bear.append("MTF confluence")
    elif mtf_conf=="MIXED": bull*=0.75; bear*=0.75; warns.append("Mixed MTF signals")
    if "RANGING" in condition or "WEAK" in condition: bull*=0.70; bear*=0.70; warns.append("Ranging market")
    if momentum.get("stoch_ob") and bull>bear: bull=max(bull-10,0); warns.append("Stoch overbought")
    if momentum.get("stoch_os") and bear>bull: bear=max(bear-10,0); warns.append("Stoch oversold")
    if momentum.get("rsi",50)>=70 and bull>bear: bull=max(bull-15,0); warns.append("RSI overbought")
    if momentum.get("rsi",50)<=30 and bear>bull: bear=max(bear-15,0); warns.append("RSI oversold")
    max_score=max(bull,bear); min_prob=THRESHOLDS["min_probability"]
    if bull>bear and max_score>=min_prob: direction,raw_prob,factors="BUY",bull,factors_bull
    elif bear>bull and max_score>=min_prob: direction,raw_prob,factors="SELL",bear,factors_bear
    else: direction,raw_prob,factors="NO TRADE",max_score,["Insufficient confluence"]
    probability=min(round(raw_prob),THRESHOLDS["max_probability"])
    confidence="HIGH" if probability>=THRESHOLDS["high_confidence"] else "MEDIUM" if probability>=min_prob else "LOW"
    return {"direction":direction,"probability":probability,"confidence":confidence,
            "factors":factors,"warnings":warns,"bull_score":round(bull,1),"bear_score":round(bear,1)}

def mtf_confluence(tf_trends):
    bull_count=0; bear_count=0; summary={}
    for tf_name,data in tf_trends.items():
        t=data.get("trend","UNKNOWN"); summary[tf_name]=t
        if "BULLISH" in t: bull_count+=1
        elif "BEARISH" in t: bear_count+=1
    if bull_count>=2: confluence="BULLISH"
    elif bear_count>=2: confluence="BEARISH"
    else: confluence="MIXED"
    return {"confluence":confluence,"aligned_count":max(bull_count,bear_count),
            "breakdown":summary,"total_tfs":len(tf_trends)}
