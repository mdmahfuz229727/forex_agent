
PAIRS = ["EURUSD=X","GBPUSD=X","USDJPY=X","AUDUSD=X","USDCAD=X"]
TIMEFRAMES = {"trend":"1d","structure":"4h","entry":"1h","confirm":"15m"}
PRIMARY_TF = "entry"
INDICATORS = {"ema_fast":20,"ema_slow":50,"ema_trend":200,"rsi_period":14,
"rsi_overbought":70,"rsi_oversold":30,"macd_fast":12,"macd_slow":26,
"macd_signal":9,"atr_period":14,"bb_period":20,"bb_std":2.0,
"stoch_k":14,"stoch_d":3,"stoch_smooth":3,"stoch_ob":80,"stoch_os":20,
"adx_period":14,"adx_threshold":25}
RISK = {"account_balance":1000,"risk_per_trade_pct":1.0,"max_daily_trades":3,
"min_rr_ratio":1.5,"sl_atr_multiplier":1.5,"tp_atr_multiplier":3.0,
"max_consecutive_losses":3}
SESSIONS = {"sydney":(22,7),"tokyo":(0,9),"london":(8,16),"new_york":(13,21),"overlap":(13,16)}
WEIGHTS = {"trend_strong":40,"trend_weak":20,"macd":15,"rsi":10,
"stochastic":5,"pullback":10,"session_bonus":10,"mtf_confluence":15}
THRESHOLDS = {"min_probability":55,"high_confidence":70,"max_probability":85}
ANTHROPIC_API_KEY = ""
AI_SETTINGS = {"use_ai":False,"max_tokens":600,"model":"claude-sonnet-4-20250514"}
DISPLAY = {"show_raw_scores":False,"show_all_pairs":False,"log_to_file":False,"journal_file":"forex_journal.json"}
