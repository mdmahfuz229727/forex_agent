
import yfinance as yf
import pandas as pd
from config import TIMEFRAMES

TF_CONFIG = {
    "15m":{"interval":"15m","period":"5d"},
    "1h":{"interval":"1h","period":"30d"},
    "4h":{"interval":"1h","period":"60d"},
    "1d":{"interval":"1d","period":"200d"},
}

def fetch_ohlcv(symbol, timeframe, bars=200):
    if timeframe not in TF_CONFIG:
        return None
    cfg = TF_CONFIG[timeframe]
    try:
        ticker = yf.Ticker(symbol)
        df = ticker.history(period=cfg["period"],interval=cfg["interval"],auto_adjust=True)
        if df is None or df.empty:
            return None
        df = df[["Open","High","Low","Close","Volume"]].copy()
        df.columns = ["open","high","low","close","volume"]
        df = df.dropna()
        if timeframe == "4h":
            df = df.resample("4h").agg({"open":"first","high":"max","low":"min","close":"last","volume":"sum"}).dropna()
        df = df.tail(bars)
        if len(df) < 50:
            return None
        return df
    except Exception as e:
        print(f"Error: {e}")
        return None

def fetch_all_timeframes(symbol):
    result = {}
    for name, tf in TIMEFRAMES.items():
        bars = 200 if tf in ["1d","4h"] else 150
        df = fetch_ohlcv(symbol, tf, bars=bars)
        if df is not None:
            result[name] = df
    return result

def format_symbol_name(symbol):
    clean = symbol.replace("=X","")
    if len(clean) == 6:
        return f"{clean[:3]}/{clean[3:]}"
    return clean
