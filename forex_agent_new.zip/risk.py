
from config import RISK

def calculate_levels(df, direction):
    last=df.iloc[-1]; price=float(last["close"]); atr=float(last.get("atr") or 0)
    if not atr: return {"error":"ATR not available"}
    sl_dist=atr*RISK["sl_atr_multiplier"]; tp_dist=atr*RISK["tp_atr_multiplier"]
    if direction=="BUY": sl,tp=price-sl_dist,price+tp_dist
    elif direction=="SELL": sl,tp=price+sl_dist,price-tp_dist
    else: return {}
    rr=round(tp_dist/sl_dist,2); risk_amt=RISK["account_balance"]*(RISK["risk_per_trade_pct"]/100)
    pip_mult=100 if sl_dist>0.1 else 10000
    return {"entry":round(price,5),"stop_loss":round(sl,5),"take_profit":round(tp,5),
            "sl_pips":round(sl_dist*pip_mult,1),"tp_pips":round(tp_dist*pip_mult,1),
            "rr_ratio":rr,"risk_amount":round(risk_amt,2),"risk_pct":RISK["risk_per_trade_pct"],
            "meets_min_rr":rr>=RISK["min_rr_ratio"],"atr":round(atr,5)}
