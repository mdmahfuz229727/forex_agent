
from datetime import datetime
import pytz
from config import SESSIONS

def get_session():
    utc_now = datetime.now(pytz.UTC)
    h = utc_now.hour
    in_london  = SESSIONS["london"][0]  <= h < SESSIONS["london"][1]
    in_ny      = SESSIONS["new_york"][0]<= h < SESSIONS["new_york"][1]
    in_overlap = SESSIONS["overlap"][0] <= h < SESSIONS["overlap"][1]
    in_tokyo   = (h >= SESSIONS["tokyo"][0] or h < SESSIONS["tokyo"][1])
    if in_overlap: name,quality,note,score="LONDON-NY OVERLAP","EXCELLENT","Highest liquidity",10
    elif in_london: name,quality,note,score="LONDON SESSION","GOOD","Good for EUR/GBP",7
    elif in_ny: name,quality,note,score="NEW YORK SESSION","GOOD","Good for USD pairs",7
    elif in_tokyo: name,quality,note,score="TOKYO SESSION","FAIR","Best for JPY",4
    else: name,quality,note,score="OFF-SESSION","POOR","Low liquidity",0
    return {"name":name,"quality":quality,"note":note,"score":score,
            "time_utc":utc_now.strftime("%H:%M UTC"),"date":utc_now.strftime("%Y-%m-%d"),
            "recommended":quality in ["EXCELLENT","GOOD"],
            "in_london":in_london,"in_ny":in_ny,"in_overlap":in_overlap}
