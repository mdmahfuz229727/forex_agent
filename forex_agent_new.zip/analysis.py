
import pandas as pd
import numpy as np

def ema(series, period):
    return series.ewm(span=period, adjust=False).mean()

def rsi(series, period=14):
    delta = series.diff()
    gain = delta.where(delta > 0, 0).rolling(period).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(period).mean()
    rs = gain / loss
    return 100 - (100 / (1 + rs))

def atr(high, low, close, period=14):
    tr = pd.concat([high-low, (high-close.shift()).abs(), (low-close.shift()).abs()], axis=1).max(axis=1)
    return tr.rolling(period).mean()

def add_indicators(df):
    df = df.copy()
    df["ema20"]  = ema(df["close"], 20)
    df["ema50"]  = ema(df["close"], 50)
    df["ema200"] = ema(df["close"], 200)
    df["atr"]    = atr(df["high"], df["low"], df["close"], 14)
    r = rsi(df["close"], 14)
    df["rsi"] = r
    delta = df["close"].diff()
    gain = delta.where(delta>0,0).rolling(14).mean()
    loss = (-delta.where(delta<0,0)).rolling(14).mean()
    df["macd"] = ema(df["close"],12) - ema(df["close"],26)
    df["macd_sig"] = ema(df["macd"],9)
    df["macd_hist"] = df["macd"] - df["macd_sig"]
    bb_mid = df["close"].rolling(20).mean()
    bb_std = df["close"].rolling(20).std()
    df["bb_upper"] = bb_mid + 2*bb_std
    df["bb_middle"] = bb_mid
    df["bb_lower"] = bb_mid - 2*bb_std
    low14  = df["low"].rolling(14).min()
    high14 = df["high"].rolling(14).max()
    df["stoch_k"] = 100*(df["close"]-low14)/(high14-low14)
    df["stoch_d"] = df["stoch_k"].rolling(3).mean()
    return df.dropna(subset=["ema20","rsi","atr"])

def analyze_trend(df):
    if len(df) < 10:
        return {"trend":"UNKNOWN","trend_score":0,"bull_align":False,"bear_align":False,
                "hh_hl":False,"lh_ll":False,"price":0,"ema20":0,"ema50":0,"ema200":None}
    last = df.iloc[-1]
    c   = float(last["close"])
    e20 = float(last["ema20"])
    e50 = float(last["ema50"])
    e200_raw = last["ema200"]
    e200 = float(e200_raw) if e200_raw is not None and not pd.isna(e200_raw) else None
    bull_align = (e20>e50>e200) if e200 else (e20>e50)
    bear_align = (e20<e50<e200) if e200 else (e20<e50)
    price_above = c>e20>e50
    price_below = c<e20<e50
    recent = df.tail(20)
    highs = recent["high"].values
    lows  = recent["low"].values
    hh = len(highs)>=10 and highs[-1]>highs[-5] and highs[-5]>highs[-10]
    hl = len(lows)>=10  and lows[-1]>lows[-5]   and lows[-5]>lows[-10]
    lh = len(highs)>=10 and highs[-1]<highs[-5] and highs[-5]<highs[-10]
    ll = len(lows)>=10  and lows[-1]<lows[-5]   and lows[-5]<lows[-10]
    if bull_align and price_above and hh and hl: trend,score="STRONG BULLISH",90
    elif bull_align and price_above: trend,score="BULLISH",70
    elif bull_align: trend,score="BULLISH (PULLBACK)",55
    elif bear_align and price_below and lh and ll: trend,score="STRONG BEARISH",90
    elif bear_align and price_below: trend,score="BEARISH",70
    elif bear_align: trend,score="BEARISH (PULLBACK)",55
    else: trend,score="RANGING",20
    return {"trend":trend,"trend_score":score,"bull_align":bull_align,"bear_align":bear_align,
            "hh_hl":hh and hl,"lh_ll":lh and ll,"price":round(c,5),
            "ema20":round(e20,5),"ema50":round(e50,5),"ema200":round(e200,5) if e200 else None}

def analyze_momentum(df):
    last = df.iloc[-1]
    prev = df.iloc[-2]
    rsi_val = float(last.get("rsi") or 50)
    if rsi_val>=70: rsi_label,rsi_score="OVERBOUGHT",-15
    elif rsi_val<=30: rsi_label,rsi_score="OVERSOLD",+15
    elif rsi_val>=55: rsi_label,rsi_score="BULLISH MOMENTUM",+10
    elif rsi_val<=45: rsi_label,rsi_score="BEARISH MOMENTUM",-10
    else: rsi_label,rsi_score="NEUTRAL",0
    m=last.get("macd"); ms=last.get("macd_sig"); mh=last.get("macd_hist")
    pm=prev.get("macd"); pms=prev.get("macd_sig"); pmh=prev.get("macd_hist")
    macd_bull = bool(m and ms and pm and pms and float(m)>float(ms) and float(pm)<=float(pms))
    macd_bear = bool(m and ms and pm and pms and float(m)<float(ms) and float(pm)>=float(pms))
    sk=float(last.get("stoch_k") or 50); sd=float(last.get("stoch_d") or 50)
    psk=float(prev.get("stoch_k") or 50); psd=float(prev.get("stoch_d") or 50)
    return {"rsi":round(rsi_val,1),"rsi_label":rsi_label,"rsi_score":rsi_score,
            "macd":round(float(m),5) if m else 0,"macd_hist":round(float(mh),5) if mh else 0,
            "macd_bull_cross":macd_bull,"macd_bear_cross":macd_bear,
            "macd_above_zero":bool(m and float(m)>0),"macd_hist_rising":bool(mh and pmh and float(mh)>float(pmh)),
            "stoch_k":round(sk,1),"stoch_d":round(sd,1),
            "stoch_bull_cross":bool(sk>sd and psk<=psd),"stoch_bear_cross":bool(sk<sd and psk>=psd),
            "stoch_ob":sk>80,"stoch_os":sk<20}

def analyze_volatility(df):
    last=df.iloc[-1]
    atr_val=float(last.get("atr") or 0)
    atr_avg=float(df["atr"].tail(20).mean()) if "atr" in df.columns else 0
    bu=float(last.get("bb_upper") or 0); bl=float(last.get("bb_lower") or 0)
    bm=float(last.get("bb_middle") or 0); c=float(last["close"])
    bb_width=bu-bl; bb_pos=(c-bl)/bb_width if bb_width>0 else 0.5
    atr_ratio=atr_val/atr_avg if atr_avg>0 else 1
    vol="HIGH" if atr_ratio>1.3 else "LOW" if atr_ratio<0.7 else "NORMAL"
    return {"atr":round(atr_val,5),"atr_avg":round(atr_avg,5),"volatility":vol,
            "bb_position":round(bb_pos,2),"near_upper_bb":bb_pos>0.85,
            "near_lower_bb":bb_pos<0.15,"near_middle_bb":0.4<bb_pos<0.6,
            "bb_squeeze":False,"bb_upper":round(bu,5),"bb_middle":round(bm,5),"bb_lower":round(bl,5)}

def detect_market_condition(df):
    last=df.iloc[-1]
    spread=abs(float(last["ema20"])-float(last["ema50"]))/float(last["close"])*100
    if spread>0.5: return "TRENDING",None
    elif spread>0.2: return "WEAK TREND",None
    else: return "RANGING",None

def detect_pullback(df, trend_data):
    last=df.iloc[-1]
    c=float(last["close"]); e20=float(last["ema20"]); e50=float(last["ema50"])
    bull="BULLISH" in trend_data.get("trend","")
    bear="BEARISH" in trend_data.get("trend","")
    bull_pb=bull and c<=e20*1.002 and c>=e50*0.998
    bear_pb=bear and c>=e20*0.998 and c<=e50*1.002
    is_pb=bull_pb or bear_pb
    direction="BULLISH" if bull_pb else "BEARISH" if bear_pb else None
    near_e20=abs(c-e20)/e20<0.003; near_e50=abs(c-e50)/e50<0.003
    return {"is_pullback":is_pb,"direction":direction,"near_ema20":near_e20,
            "near_ema50":near_e50,"near_lower_bb":False,
            "quality":"HIGH" if (is_pb and (near_e20 or near_e50)) else "MEDIUM" if is_pb else "LOW"}
